import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useContext } from 'react';
import { AuthContext } from './context/AuthContext';
import Welcome from './pages/Welcome';
import Plans from './pages/Plans';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './dashboard/Dashboard';
import POS from './dashboard/POS';
import Inventory from './dashboard/Inventory';
import Reports from './dashboard/Reports';
import Employees from './dashboard/Employees';
import Unauthorized from './dashboard/Unauthorized';
import ProtectedRoute from './components/ProtectedRoute'; // Import corrected ProtectedRoute

function App() {
  const { user } = useContext(AuthContext);

  return (
    <Router>
      <Routes>
        {/* Public routes */}
        <Route path="/" element={<Welcome />} />
        <Route path="/plans" element={<Plans />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/unauthorized" element={<Unauthorized />} />

        {/* Protected routes */}
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        } />
        <Route path="/dashboard/pos" element={
          <ProtectedRoute allowedRoles={['cashier', 'manager']}>
            <POS />
          </ProtectedRoute>
        } />
        <Route path="/dashboard/inventory" element={
          <ProtectedRoute allowedRoles={['stocker', 'manager']}>
            <Inventory />
          </ProtectedRoute>
        } />
        <Route path="/dashboard/reports" element={
          <ProtectedRoute>
            <Reports />
          </ProtectedRoute>
        } />
        <Route path="/dashboard/employees" element={
          <ProtectedRoute>
            <Employees />
          </ProtectedRoute>
        } />
        
        {/* Catch all - redirect unknown routes */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}

export default App;
