const Unauthorized = () => (
    <div className="text-center py-20 text-red-600 text-2xl font-semibold">
      🚫 You are not authorized to view this page.
    </div>
  );
  
  export default Unauthorized;
  